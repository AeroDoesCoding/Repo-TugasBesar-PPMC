// #include "function.h"
// #include <stdio.h>
// #include <string.h>
// #include <stdlib.h>

// int main(){
//     int w,h;
//     int i,size,k;
//     char *grid = (char*) malloc(sizeof(char));
//     read_inputFile("file.txt",&grid,&w,&h);
//     print_grid(grid,w,h);
//     tick(&grid,w,h);
//     animate(&grid,w,h,60);
//     free(grid);
// }